export class TransformSnapshot {
    /**
     * @param {SceneObjectBase} sceneObject 
     */
    constructor(sceneObject, autoSnap = true) {
        this.sceneObject = sceneObject;
        if (autoSnap) this.snapshot();
    }

    snapshot() {
        this.snapshotPosition();
        this.snapshotRotation();
        this.snapshotScale();
    }

    snapshotPosition() {
        this.x = this.sceneObject.transform.x.pinLastValue();
        this.y = this.sceneObject.transform.y.pinLastValue();
        this.z = this.sceneObject.transform.z.pinLastValue();
    }

    snapshotRotation() {
        this.rotationX = this.sceneObject.transform.rotationX.pinLastValue();
        this.rotationY = this.sceneObject.transform.rotationY.pinLastValue();
        this.rotationZ = this.sceneObject.transform.rotationZ.pinLastValue();
    }

    snapshotScale() {
        this.scaleX = this.sceneObject.transform.scaleX.pinLastValue();
        this.scaleY = this.sceneObject.transform.scaleY.pinLastValue();
        this.scaleZ = this.sceneObject.transform.scaleZ.pinLastValue();
    }

    revert() {
        this.revertPosition();
        this.revertRotation();
        this.revertScale();
    }

    revertPosition() {
        this.sceneObject.transform.x = this.x;
        this.sceneObject.transform.y = this.y;
        this.sceneObject.transform.z = this.z;
    }

    revertRotation() {
        this.sceneObject.transform.rotationX = this.rotationX;
        this.sceneObject.transform.rotationY = this.rotationY;
        this.sceneObject.transform.rotationZ = this.rotationZ;
    }

    revertScale() {
        this.sceneObject.transform.scaleX = this.scaleX;
        this.sceneObject.transform.scaleY = this.scaleY;
        this.sceneObject.transform.scaleZ = this.scaleZ;
    }
}