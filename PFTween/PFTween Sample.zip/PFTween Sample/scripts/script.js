import { PFTween, Ease } from './PFTween';
import { TransformSnapshot } from './TransformSnapshot';
import { invokeOnce } from './Util';


const Scene = require('Scene');
const TouchGestures = require('TouchGestures');
const Diagnostics = require('Diagnostics');

Diagnostics.log('1. Tap to start animation sequence');
Diagnostics.log('2. LongPress to rotate plane2');

//–––––––––––––––––––––––––––––––––––––––––––––––– Bind Animation Method 1
const plane1 = Scene.root.find('plane1');
plane1.transform.x = new PFTween(-0.1, 0.1, 1000)
    .setMirror()
    .setLoop()
    .scalar;

//–––––––––––––––––––––––––––––––––––––––––––––––– Bind Animation Method 2
const plane2 = Scene.root.find('plane2');
const ani = new PFTween(0, 360, 1000)
    .setLoop(2)
    .setEase(Ease.easeOutCubic)
    .setMirror()
    .bind(v => plane2.transform.rotationZ = v.rotation)
    .apply();

TouchGestures.onLongPress().subscribe(() => ani.replay());

Diagnostics.watch('plane2 is rotating: ', ani.isRuning);


//–––––––––––––––––––––––––––––––––––––––––––––––– Sequence Animation with Promise
const plane = Scene.root.find('plane_ani_promise');
const snapshot = new TransformSnapshot(plane);

invokeOnce(TouchGestures.onTap(), play);

function play() {
    snapshot.revert();

    new PFTween(0, 0.1, 1000)
        .setEase(Ease.easeInOutCirc)
        .setMirror()
        .setLoop(2)
        .bind(tweener => plane.transform.x = tweener.scalar)
        .promise
        .then(() =>
            new PFTween(0, 0.1, 1000)
                .setEase(Ease.easeOutBounce)
                .setDelay(1000)
                .bind(tweener => plane.transform.y = tweener.scalar)
                .promise
        )
        .then(() =>
            Promise.all(
                [
                    new PFTween(plane.transform.rotationZ, 270, 1000)
                        .setEase(Ease.easeOutQuart)
                        .bind(tweener => plane.transform.rotationZ = tweener.rotation)
                        .promise,

                    new PFTween(plane.transform.scaleX, 2.5, 1000)
                        .setEase(Ease.easeOutBack)
                        .bind(tweener => plane.transform.scale = tweener.scale)
                        .promise
                ]
            )
        )
        .then(() =>
            new PFTween(plane.transform.scaleX, 0, 1000)
                .setEase(Ease.easeInBack)
                .bind(tweener => plane.transform.scale = tweener.scale)
                .promise
        )
        .then(play)
}


