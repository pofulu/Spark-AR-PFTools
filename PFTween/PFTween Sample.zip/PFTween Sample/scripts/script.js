import { PFTween, Ease } from './PFTween';
import { TransformSnapshot } from './TransformSnapshot';
import { invokeOnce } from './Util';

const Scene = require('Scene');
const TouchGestures = require('TouchGestures');
const Diagnostics = require('Diagnostics');

Diagnostics.log('1. Tap to start animation sequence');
Diagnostics.log('2. LongPress to rotate plane2');

//–––––––––––––––––––––––––––––––––––––––––––––––– Bind Animation Method 1
const plane1 = Scene.root.find('plane1');
plane1.transform.x = new PFTween(-0.1, 0.1, 1000)
    .setMirror()
    .setLoops()
    .scalar;

//–––––––––––––––––––––––––––––––––––––––––––––––– Bind Animation Method 2
const plane2 = Scene.root.find('plane2');
const ani = new PFTween(0, 360, 1000)
    .setLoops(2)
    .setEase(Ease.easeOutCubic)
    .setMirror()
    .bind(v => plane2.transform.rotationZ = v.rotation)
    .apply();

TouchGestures.onLongPress().subscribe(() => ani.replay());

Diagnostics.watch('plane2 is rotating: ', ani.isRuning);


//–––––––––––––––––––––––––––––––––––––––––––––––– Sequence Animation with Promise
const plane = Scene.root.find('plane_ani_promise');
const snapshot = new TransformSnapshot(plane);

invokeOnce(TouchGestures.onTap(), play);

const moveX = new PFTween(0, 0.1, 1000)
    .setMirror()
    .setLoops(2)
    .setEase(Ease.easeInOutCirc)
    .bind(tweener => plane.transform.x = tweener.scalar).clip;

const rotateZ = new PFTween(plane.transform.rotationZ, 270, 1000)
    .setEase(Ease.easeOutQuart)
    .bind(tweener => plane.transform.rotationZ = tweener.rotation)
    .clip;

const scaleIn = new PFTween(plane.transform.scaleX, 2.5, 1000)
    .setEase(Ease.easeOutBack)
    .bind(tweener => plane.transform.scale = tweener.scale)
    .clip;

const combine = PFTween.combine(rotateZ, scaleIn);

const scaleOut = new PFTween(plane.transform.scaleX, 0, 1000)
    .setEase(Ease.easeInBack)
    .bind(tweener => plane.transform.scale = tweener.scale)

function play() {
    snapshot.revert();

    rotateZ()
        .then(moveX)
        .then(combine)
        .then(moveX)
        .then(() => scaleOut.setBegin(plane.transform.scaleX).clip())
        .then(play);
}