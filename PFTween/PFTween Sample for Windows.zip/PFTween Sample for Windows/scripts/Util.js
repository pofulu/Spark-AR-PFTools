const Diagnostics = require('Diagnostics');

function IsSignal(value) {
    return value != undefined && typeof value.pinLastValue === 'function';
}

function IsSceneObject(input) {
    return input.child != undefined && typeof input.child == 'function';
}

function IsEventSource(value) {
    return value != undefined && typeof value.unsubscribe === 'function';
}

/**
 *
 * @param {EventSource} eventSource
 * @param {{(any?:any):void}} call
 */
function invokeOnce(eventSource, call) {
    const once = eventSource.subscribe(any => {
        call(any);
        once.unsubscribe();
    });
}

/**
 *
 * @param {EventSource[]} eventSourceList
 * @param {{(any?:any):void}} call
 */
function invokeOnceList(eventSourceList, call) {
    let events = [];
    eventSourceList.forEach(i => {
        events.push(i.subscribe(any => {
            call(any);
            unsubscribeAll();
        }));
    })

    function unsubscribeAll() {
        events.forEach(e => {
            e.unsubscribe();
        });
    }
}

/**
 * 
 * @param {EventSource[]} eventSourceList 
 * @param {{(any?:any):void}} call 
 */
function subscribeList(eventSourceList, call) {
    eventSourceList.forEach(i => {
        i.subscribe(call);
    });
}

export { IsSignal, IsSceneObject, IsEventSource, invokeOnce, invokeOnceList, subscribeList };